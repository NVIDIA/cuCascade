# Excluded diagnostic attempt

This complete attempt is excluded from normal-consumer performance conclusions because both extensions were linked with an inadvertently private RMM registry. Restoring normal cross-DSO resource registration requires new artifacts and a restarted prespecified experiment. Additionally a CPU-heavy analysis overlapped some baseline samples; no result selection is based on measured improvement. Preserve existing files as diagnostic history only. Root terminated the owned process group before completing the schedule.
